PRAGMA foreign_keys = ON;

drop trigger check_capacity;