PRAGMA foreign_keys = ON;

DROP TRIGGER RemoveFunc;
DROP TRIGGER RestraintRem;
DROP TRIGGER RestraintAddProcEnf;
DROP TRIGGER RestraintAddProcMed;