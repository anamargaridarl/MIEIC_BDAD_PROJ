PRAGMA foreign_keys = ON;

DROP TRIGGER DecrementVagas;
DROP TRIGGER IncrementVagas;
DROP TRIGGER RestraintVagas;